export FLASK_APP=hello.py
export FLASK_DEBUG=1
flask run
